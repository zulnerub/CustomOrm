package softuni.exam.models.enums;

public enum Rating {
    GOOD, BAD, UNKNOWN;
}
