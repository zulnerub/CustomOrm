package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import softuni.exam.models.dtos.CarSeedDto;
import softuni.exam.models.entities.Car;
import softuni.exam.repository.CarRepository;
import softuni.exam.service.CarService;
import softuni.exam.util.ValidationUtil;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

import static softuni.exam.constants.GlobalConstants.CARS_PATH;

@Service
@Transactional
public class CarServiceImpl implements CarService {
    private final CarRepository carRepository;
    private final Gson gson;
    private final ModelMapper modelMapper;
    private final ValidationUtil validationUtil;

    @Autowired
    public CarServiceImpl(CarRepository carRepository, Gson gson, ModelMapper modelMapper, ValidationUtil validationUtil) {
        this.carRepository = carRepository;
        this.gson = gson;
        this.modelMapper = modelMapper;
        this.validationUtil = validationUtil;
    }


    @Override
    public boolean areImported() {
        return this.carRepository.count() > 0;
    }

    @Override
    public String readCarsFileContent() throws IOException {
        return Files.readString(Path.of(CARS_PATH));
    }

    @Override
    public String importCars() throws IOException {
        StringBuilder sb = new StringBuilder();

        CarSeedDto[] cars = this.gson
                .fromJson(new FileReader(CARS_PATH), CarSeedDto[].class);

        Arrays.stream(cars)
                .forEach(carSeedDto -> {
                    if (this.validationUtil.isValid(carSeedDto)) {

                        Car car = this.modelMapper
                                .map(carSeedDto, Car.class);
                    if (this.carRepository.findByMakeAndModelAndKilometers(car.getMake(), car.getModel(), car.getKilometers()) == null){
                        sb.append("Successfully imported ").append(car.getMake()).append(" - ").append(car.getModel());

                        this.carRepository.saveAndFlush(car);
                    }else{
                        sb.append("Invalid car");
                    }

                    } else {
                        sb.append("Invalid car");
                    }
                    sb.append(System.lineSeparator());
                });






        return sb.toString();
    }

    @Override
    public String getCarsOrderByPicturesCountThenByMake() {
        return null;
    }
}
